#!/usr/bin/env python3
"""Train Spread (XGBoost) and Totals (Linear + XGBoost) pipelines.
Expects processed CSVs in data/processed/ -- will use the most recent file.
"""
import joblib
import glob, os
from pathlib import Path
import pandas as pd
from datetime import datetime
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error, r2_score

BASE_DIR = Path(__file__).resolve().parents[1]
PROCESSED_DIR = BASE_DIR / 'data' / 'processed'
MODELS_DIR = BASE_DIR / 'models'
MODELS_DIR.mkdir(parents=True, exist_ok=True)

def find_latest_processed():
    files = sorted(PROCESSED_DIR.glob('*processed.csv'), reverse=True)
    return files[0] if files else None

def train():
    p = find_latest_processed()
    if not p:
        print('No processed CSV found in data/processed. Run preprocess first.' )
        return
    df = pd.read_csv(p)
    # minimal required features check
    # default safe features (may be adjusted to your processed output)
    numeric_features = ['home_score','away_score']
    categorical_features = ['home_team','away_team']
    # targets
    if 'Spread' not in df.columns or 'Totals' not in df.columns:
        print('Targets not found (Spread/Totals). Exiting.'); return
    # simple features: use team IDs / names as categorical and home/away scores as numeric (if available)
    X = df[numeric_features + categorical_features].fillna(0)
    y_spread = df['Spread']
    y_totals = df['Totals']

    X_train, X_test, y_spread_train, y_spread_test = train_test_split(X, y_spread, test_size=0.2, random_state=42)
    _, _, y_totals_train, y_totals_test = train_test_split(X, y_totals, test_size=0.2, random_state=42)

    preprocessor = ColumnTransformer([
        ('num', StandardScaler(), numeric_features),
        ('cat', OneHotEncoder(handle_unknown='ignore', sparse=False), categorical_features)
    ])

    # Spread pipeline (XGBoost)
    spread_pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('regressor', XGBRegressor(objective='reg:squarederror', n_estimators=200, learning_rate=0.05, random_state=42))
    ])
    print('Training spread model...')
    spread_pipeline.fit(X_train, y_spread_train)
    y_pred = spread_pipeline.predict(X_test)
    print('Spread RMSE:', mean_squared_error(y_spread_test, y_pred, squared=False))
    print('Spread R2:', r2_score(y_spread_test, y_pred))
    joblib.dump(spread_pipeline, MODELS_DIR / 'spread_pipeline.pkl')
    print('Saved spread_pipeline.pkl')

    # Totals baseline (Linear) and XGB
    totals_lr = Pipeline([('preprocessor', preprocessor), ('regressor', LinearRegression())])
    totals_lr.fit(X_train, y_totals_train)
    y_pred_lr = totals_lr.predict(X_test)
    print('Totals LR RMSE:', mean_squared_error(y_totals_test, y_pred_lr, squared=False))
    print('Totals LR R2:', r2_score(y_totals_test, y_pred_lr))
    joblib.dump(totals_lr, MODELS_DIR / 'totals_lr_pipeline.pkl')
    print('Saved totals_lr_pipeline.pkl')

    totals_xgb = Pipeline([('preprocessor', preprocessor),
                           ('regressor', XGBRegressor(objective='reg:squarederror', n_estimators=200, learning_rate=0.05, random_state=42))])
    totals_xgb.fit(X_train, y_totals_train)
    y_pred_xgb = totals_xgb.predict(X_test)
    print('Totals XGB RMSE:', mean_squared_error(y_totals_test, y_pred_xgb, squared=False))
    print('Totals XGB R2:', r2_score(y_totals_test, y_pred_xgb))
    joblib.dump(totals_xgb, MODELS_DIR / 'totals_xgb_pipeline.pkl')
    print('Saved totals_xgb_pipeline.pkl')

if __name__ == '__main__':
    train()
