#!/usr/bin/env python3
"""Minimal preprocessing: flatten ESPN 'scoreboard' JSON -> CSV with basic fields.
- Finds latest raw JSON file for the given sport (or all), extracts event list and basic scores.
- Computes Spread and Totals where possible.
Usage: python scripts/preprocess.py --sport basketball.nba
"""
import argparse, json, glob, os
from pathlib import Path
import pandas as pd
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parents[1]
RAW_DIR = BASE_DIR / 'data' / 'raw'
PROCESSED_DIR = BASE_DIR / 'data' / 'processed'
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)

def find_latest_raw(sport_key):
    files = sorted(RAW_DIR.glob(f"*_{sport_key}*.json"), reverse=True)
    return files[0] if files else None

def extract_games_from_scoreboard(json_payload):
    events = json_payload.get('events') or []
    rows = []
    for ev in events:
        comp = ev.get('competitions', [{}])[0]
        teams = comp.get('competitors', [])
        if len(teams) >= 2:
            try:
                home = next(t for t in teams if t.get('homeAway')=='home')
                away = next(t for t in teams if t.get('homeAway')=='away')
            except StopIteration:
                # fallback: first/second
                home = teams[0]; away = teams[1]
            row = {
                'game_id': ev.get('id'),
                'date': ev.get('date'),
                'home_team': home.get('team', {}).get('name'),
                'away_team': away.get('team', {}).get('name'),
                'home_score': int(home.get('score')) if home.get('score') not in (None, '') else None,
                'away_score': int(away.get('score')) if away.get('score') not in (None, '') else None,
                'status': comp.get('status', {}).get('type', {}).get('description')
            }
            rows.append(row)
    return rows

def process_file(path):
    with open(path) as f:
        payload = json.load(f)
    rows = extract_games_from_scoreboard(payload)
    if not rows:
        print(f"No events found in {path}"); return None
    df = pd.DataFrame(rows)
    # compute targets where scores exist
    if 'home_score' in df.columns and df['home_score'].notna().any():
        df['Spread'] = df['home_score'] - df['away_score']
        df['Totals'] = df['home_score'] + df['away_score']
    # save processed CSV
    date_str = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    out_path = PROCESSED_DIR / f"{date_str}_processed.csv"
    df.to_csv(out_path, index=False)
    print(f"Saved processed data: {out_path}")
    return out_path

def main(sport=None):
    if sport:
        latest = find_latest_raw(sport.replace('.', '_'))
        if not latest:
            print(f"No raw file found for {sport}"); return
        process_file(latest)
    else:
        # process all raw files in directory
        raw_files = sorted(RAW_DIR.glob('*.json'), reverse=True)
        for p in raw_files:
            try:
                process_file(p)
            except Exception as e:
                print('Error', p, e)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--sport', type=str, help='sport key like basketball.nba')
    args = parser.parse_args()
    main(sport=args.sport)
