#!/usr/bin/env python3
"""Fetch data from ESPN endpoints defined in config/espn_endpoints.json.
Saves raw JSON under data/raw/YYYYMMDD_<sport>.json
Usage: python scripts/fetch_data.py --sport basketball.nba
If --sport is omitted, fetches all top-level entries in config.
"""
import argparse, json, requests, os, time
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
CONFIG_PATH = BASE_DIR / 'config' / 'espn_endpoints.json'
RAW_DIR = BASE_DIR / 'data' / 'raw'
RAW_DIR.mkdir(parents=True, exist_ok=True)

def load_config(path=CONFIG_PATH):
    with open(path) as f:
        return json.load(f)

def fetch_url(url, timeout=10):
    for attempt in range(3):
        try:
            r = requests.get(url, timeout=timeout)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            print(f"Fetch error (attempt {attempt+1}/3) for {url}: {e}")
            time.sleep(1 + attempt)
    return None

def save_raw(payload, key):
    date_str = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    filename = RAW_DIR / f"{date_str}_{key}.json"
    with open(filename, 'w') as f:
        json.dump(payload, f)
    print(f"Saved: {filename}")
    return filename

def fetch_sport(cfg, sport_key):
    # cfg may be nested (football: {college: {...}, nfl: {...}})
    if isinstance(cfg, dict):
        for sub, subcfg in cfg.items():
            if isinstance(subcfg, dict) and 'scores' in subcfg:
                url = subcfg['scores']
                print(f"Fetching {sport_key}.{sub} -> {url}")
                payload = fetch_url(url)
                if payload:
                    save_raw(payload, f"{sport_key}.{sub}.scores")
            else:
                # dive deeper
                fetch_sport(subcfg, f"{sport_key}.{sub}" if sport_key else sub)
    else:
        print("Unsupported config structure for", sport_key)

def main(sport=None):
    cfg = load_config()
    if sport:
        # sport like 'basketball.nba' or 'football.college'
        parts = sport.split('.')
        cur = cfg
        try:
            for p in parts:
                cur = cur[p]
        except KeyError:
            print(f"Unknown sport path: {sport}")
            return
        fetch_sport({parts[-1]: cur}, '.'.join(parts))
    else:
        # fetch top-level keys
        for k, v in cfg.items():
            fetch_sport(v, k)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--sport', type=str, help="dot-separated sport path in config (e.g., basketball.nba)")
    args = parser.parse_args()
    main(sport=args.sport)
