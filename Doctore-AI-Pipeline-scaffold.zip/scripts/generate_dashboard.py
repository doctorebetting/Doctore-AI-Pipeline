#!/usr/bin/env python3
"""Generate dashboard-ready JSON combining predictions + explanations.
Expects model pipelines and a processed CSV to exist.
"""
import joblib, json
from pathlib import Path
import pandas as pd
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parents[1]
PROCESSED_DIR = BASE_DIR / 'data' / 'processed'
MODELS_DIR = BASE_DIR / 'models'
OUT = PROCESSED_DIR / f"{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_dashboard.json"

def find_latest_processed():
    files = sorted(PROCESSED_DIR.glob('*processed.csv'), reverse=True)
    return files[0] if files else None

def main():
    proc = find_latest_processed()
    if not proc:
        print('No processed file found. Run preprocess.py first.'); return
    df = pd.read_csv(proc)
    # minimal columns required
    if 'home_team' not in df.columns or 'away_team' not in df.columns:
        print('Processed file missing required columns'); return
    # Load models
    spread = joblib.load(MODELS_DIR / 'spread_pipeline.pkl')
    totals = joblib.load(MODELS_DIR / 'totals_xgb_pipeline.pkl')
    # predict
    X = df[['home_score','away_score','home_team','away_team']].fillna(0)
    df['predicted_spread'] = spread.predict(X)
    df['predicted_total'] = totals.predict(X)
    # attach shap if available
    shap_files = sorted(PROCESSED_DIR.glob('*_shap.csv'), reverse=True)
    if shap_files:
        shap_df = pd.read_csv(shap_files[0])
        merged = df.merge(shap_df[['game_id','top_feature','top_shap_value']], on='game_id', how='left')
    else:
        merged = df
        merged['top_feature'] = None
        merged['top_shap_value'] = None
    # format output
    out = []
    for _, r in merged.iterrows():
        out.append({
            'game_id': r.get('game_id'),
            'date': r.get('date'),
            'sport': r.get('sport', 'unknown'),
            'home_team': r.get('home_team'),
            'away_team': r.get('away_team'),
            'predicted_spread': float(r.get('predicted_spread') or 0),
            'predicted_total': float(r.get('predicted_total') or 0),
            'top_reason': r.get('top_feature'),
            'top_reason_value': float(r.get('top_shap_value') or 0)
        })
    with open(OUT, 'w') as f:
        json.dump(out, f, indent=2)
    print('Saved dashboard JSON to', OUT)

if __name__ == '__main__':
    main()
