#!/usr/bin/env python3
"""Compute SHAP explanations for XGBoost models saved as pipelines.
Outputs a CSV with top contributing feature per game for dashboard usage.
"""
import joblib
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parents[1]
PROCESSED_DIR = BASE_DIR / 'data' / 'processed'
MODELS_DIR = BASE_DIR / 'models'
OUTPUT = PROCESSED_DIR / f"{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_shap.csv"

def find_latest_processed():
    files = sorted(PROCESSED_DIR.glob('*processed.csv'), reverse=True)
    return files[0] if files else None

def main():
    proc = find_latest_processed()
    if not proc:
        print('No processed file found. Run preprocess.py first.'); return
    df = pd.read_csv(proc)
    X = df.select_dtypes(include=['number']).fillna(0)
    # Load spread pipeline
    try:
        spread_pipeline = joblib.load(MODELS_DIR / 'spread_pipeline.pkl')
    except Exception as e:
        print('Could not load spread_pipeline.pkl:', e); return
    reg = spread_pipeline.named_steps['regressor']
    pre = spread_pipeline.named_steps['preprocessor']
    X_trans = pre.transform(df[['home_score','away_score','home_team','away_team']].fillna(0))
    import shap
    explainer = shap.Explainer(reg)
    shap_values = explainer(X_trans)
    top_features = []
    top_vals = []
    feature_names = pre.get_feature_names_out()
    for i in range(len(shap_values.values)):
        row = shap_values.values[i]
        idx = int(np.argmax(np.abs(row)))
        top_features.append(feature_names[idx])
        top_vals.append(row[idx])
    out = df[['game_id','date','home_team','away_team']].copy()
    out['top_feature'] = top_features
    out['top_shap_value'] = top_vals
    out.to_csv(OUTPUT, index=False)
    print('Saved SHAP explanations to', OUTPUT)

if __name__ == '__main__':
    main()
